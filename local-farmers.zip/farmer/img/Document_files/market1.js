const market = document.getElementById("markets");
const data = [
  {
    address: "Rajkot",
    hours: "Sat 8am - 1pm",
    Produce: "Fresh fruits, Vegetables, Handmade goods",
  },
  {
    address: "Jaypur",
    hours: "Sat 8am - 1pm",
    Produce: "Fresh fruits, Vegetables, Handmade goods",
  },
  {
    address: "Bhavnagar",
    hours: "Sat 8am - 1pm",
    Produce: "Fresh fruits, Vegetables, Handmade goods",
  },
  {
    address: "Tokyo",
    hours: "Sat 8am - 1pm",
    Produce: "Fresh fruits, Vegetables, Handmade goods",
  },
];
for (let i = 0; i < data.length; i++) {
  market.innerHTML = `
    <div>
    ${data[i].address}
    ${data[i].hours}
    ${data[i].Produce}
    </div>
    `;
}
